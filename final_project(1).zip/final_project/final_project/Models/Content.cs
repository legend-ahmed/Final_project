﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace final_project.Models;

public partial class Content
{
    public int Id { get; set; }
    [Display(Name = "رقم الموضوع")]

    public int TopicId { get; set; }
    [Display(Name = " عنوان الدرس")]

    public string Title { get; set; } = null!;
    [Display(Name = "وصف الدرس")]

    public string Description { get; set; } = null!;
    [Display(Name = "رابط الدرس")]

    [DataType(DataType.Url)]
    public string File { get; set; } = null!;
    public virtual ICollection<Assignment> Assignments { get; set; } = new List<Assignment>();

}
