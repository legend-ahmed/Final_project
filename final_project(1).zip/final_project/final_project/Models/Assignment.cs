﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace final_project.Models;

public partial class Assignment
{
    public int Id { get; set; }
    [Display(Name ="رقم الدرس")]
    public int ContentId { get; set; }
    [Display(Name = " السؤال")]

    public string Questiontext { get; set; } = null!;
    [Display(Name = "الخيار الاول")]

    public string Option1 { get; set; } = null!;
    [Display(Name = "الخيار الثاني")]

    public string Option2 { get; set; } = null!;
    [Display(Name = "الخيار الثالث")]

    public string Option3 { get; set; } = null!;
    [Display(Name = "الخيار الرابع")]

    public string Option4 { get; set; } = null!;
    [Display(Name = "الاجابة الصحيحة")]

    public string Correctanswer { get; set; } = null!;
}
