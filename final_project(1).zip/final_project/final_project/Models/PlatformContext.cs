﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace final_project.Models;

public partial class PlatformContext : DbContext
{
    public PlatformContext()
    {
    }

    public PlatformContext(DbContextOptions<PlatformContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Account> Accounts { get; set; }

    public virtual DbSet<Assignment> Assignments { get; set; }

    public virtual DbSet<Content> Contents { get; set; }

    public virtual DbSet<Topic> Topics { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;port=3306;database=platform;username=root", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.28-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Account>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("accounts");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("ID");
            entity.Property(e => e.Address)
                .HasColumnType("text")
                .HasColumnName("ADDRESS");
            entity.Property(e => e.Email)
                .HasColumnType("text")
                .HasColumnName("EMAIL");
            entity.Property(e => e.Name)
                .HasColumnType("text")
                .HasColumnName("NAME");
            entity.Property(e => e.Password)
                .HasColumnType("text")
                .HasColumnName("PASSWORD");
            entity.Property(e => e.PhoneNo)
                .HasColumnType("text")
                .HasColumnName("PHONE NO");
            entity.Property(e => e.TopicId)
                .HasColumnType("int(11)")
                .HasColumnName("TOPIC_ID");
            entity.Property(e => e.Type)
                .HasColumnType("text")
                .HasColumnName("TYPE");
            entity.Property(e => e.Username)
                .HasColumnType("text")
                .HasColumnName("USERNAME");
        });

        modelBuilder.Entity<Assignment>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("assignments");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("ID");
            entity.Property(e => e.ContentId)
                .HasColumnType("int(11)")
                .HasColumnName("CONTENT_ID");
            entity.Property(e => e.Correctanswer)
                .HasColumnType("text")
                .HasColumnName("CORRECTANSWER");
            entity.Property(e => e.Option1)
                .HasColumnType("text")
                .HasColumnName("OPTION1");
            entity.Property(e => e.Option2)
                .HasColumnType("text")
                .HasColumnName("OPTION2");
            entity.Property(e => e.Option3)
                .HasColumnType("text")
                .HasColumnName("OPTION3");
            entity.Property(e => e.Option4)
                .HasColumnType("text")
                .HasColumnName("OPTION4");
            entity.Property(e => e.Questiontext)
                .HasColumnType("text")
                .HasColumnName("QUESTIONTEXT");
        });

        modelBuilder.Entity<Content>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("contents");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("ID");
            entity.Property(e => e.Description)
                .HasColumnType("text")
                .HasColumnName("DESCRIPTION");
            entity.Property(e => e.File)
                .HasColumnType("text")
                .HasColumnName("FILE");
            entity.Property(e => e.Title)
                .HasColumnType("text")
                .HasColumnName("TITLE");
            entity.Property(e => e.TopicId)
                .HasColumnType("int(11)")
                .HasColumnName("TOPIC_ID");
        });

        modelBuilder.Entity<Topic>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("topics");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("ID");
            entity.Property(e => e.Title)
                .HasColumnType("text")
                .HasColumnName("TITLE");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
