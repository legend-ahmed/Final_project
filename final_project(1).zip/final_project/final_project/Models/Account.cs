﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace final_project.Models;

//public enum types
//{
//  طالب,
//  مدرس,
//  مدير,
//}
public partial class Account
{
    public int Id { get; set; }
    [Display(Name = "رقم الموضوع")]

    public int TopicId { get; set; }
    [Display(Name = " الاسم")]

    public string Name { get; set; } = null!;
    [Display(Name = " اسم المستخدم")]

    public string Username { get; set; } = null!;
    [EmailAddress]
    
    [Display(Name = "البريد الالكتروني ")]

    public string Email { get; set; } = null!;
    [DataType(DataType.Password)]
    [StringLength(8)]
    [Display(Name = " كلمة المرور")]

    public string Password { get; set; } = null!;
    [DataType(DataType.PhoneNumber)]
    [RegularExpression("7[0-9]{8}")]
    [Display(Name = " الهاتف")]

    public string PhoneNo { get; set; } = null!;
    [Display(Name = "العنوان ")]

    public string Address { get; set; } = null!;
    [Required]
    [Display(Name = " نوع الحساب")]

    
    //public types types { get; set; }
    public string Type { get; set; } = null!;
}
