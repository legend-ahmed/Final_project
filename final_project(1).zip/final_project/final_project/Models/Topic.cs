﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace final_project.Models;

public partial class Topic
{
    public int Id { get; set; }
    [Display(Name ="عنوان الدورة")]
    public string Title { get; set; } = null!;
    public virtual ICollection<Account> Accounts { get; set; } = new List<Account>();

    public virtual ICollection<Content> Contents { get; set; } = new List<Content>();

}
