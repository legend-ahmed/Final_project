﻿using final_project.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace final_project.Controllers
{
    public class HomeController : Controller
    {
        private readonly PlatformContext _context;

        
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult login(string username, string password , string type)
        {
           
           using var context =new PlatformContext();
            var user = context.Accounts.FirstOrDefault(u=>u.Username==username);
            if(user == null)
            {
                ModelState.AddModelError("", "اسم مستخدم خاطئ");

                return View("login");
            }
            if(user.Password!=password)
            {
                ModelState.AddModelError("", "كلمة المرور خاطئة");

                return RedirectToAction("login", "home");
            }
            if (user.Type == type)
            {
                return RedirectToAction("index", "accounts");
            }
            ModelState.AddModelError("", "غير مصرح بالدخول");
            return View("login");




        }
        public IActionResult tem()
        {
            return View();
        }
        public IActionResult loginlec()
        {
            return View();
        }
        [HttpPost]
        public IActionResult loginlec(string username1, string password1, string type1)
        {

            using var context = new PlatformContext();
            var user = context.Accounts.FirstOrDefault(u => u.Username == username1);
            if (user == null)
            {
                ModelState.AddModelError("", "اسم مستخدم خاطئ");
                return View("loginlec");
                
            }
            if (user.Password != password1)
            {
                ModelState.AddModelError("", "كلمة المرور خاطئة");
                return View("loginlec");
            }
            if (user.Type == type1)
            {
               
                    return RedirectToAction("index", "contents");

            }
            ModelState.AddModelError("", "غير مصرح بالدخول");
            return View("loginlec");


        }

 public IActionResult listopic()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}