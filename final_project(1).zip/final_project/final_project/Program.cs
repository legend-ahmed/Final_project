using final_project.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);
//builder.Services.AddDbContext<RedplatContext>(optionsAction: _ =>
//{
//    options.UseMySQL(connectionString: "server=localhost;port=3306;database=redplat;username=root;password=");
//});
//builder.Services.AddDbContext<RedplatContext>(options => options.UseMySql("Defualt",ServerVersion.AutoDetect("")));
//builder.Services.AddDbContext<RedplatContext>(options => options.UseMySql("Defualt",ServerVersion.AutoDetect("Defualt")));

var connectionstring = builder.Configuration.GetConnectionString("Defualt");
builder.Services.AddDbContext<PlatformContext>(options =>
{
    options.UseMySql(connectionstring, ServerVersion.AutoDetect(connectionstring));
});

builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<PlatformContext>();
// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();;

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
